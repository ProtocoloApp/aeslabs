"use client"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { useState } from "react"
import { Scan, User, Target, Activity, AlertTriangle, Zap } from "lucide-react"

const assessmentSchema = z.object({
  nome: z.string().min(2, {
    message: "Nome deve ter pelo menos 2 caracteres.",
  }),
  idade: z.coerce
    .number()
    .min(18, {
      message: "Idade deve ser maior que 18 anos.",
    })
    .max(100, {
      message: "Idade deve ser menor que 100 anos.",
    }),
  genero: z.enum(["masculino", "feminino"]),
  peso: z.coerce
    .number()
    .min(30, {
      message: "Peso deve ser maior que 30kg.",
    })
    .max(300, {
      message: "Peso deve ser menor que 300kg.",
    }),
  altura: z.coerce
    .number()
    .min(100, {
      message: "Altura deve ser maior que 100cm.",
    })
    .max(250, {
      message: "Altura deve ser menor que 250cm.",
    }),
  objetivo: z.enum([
    "perda-peso",
    "ganho-massa",
    "melhora-resistencia",
    "condicionamento-geral",
    "treinamento-forca",
    "recomposicao-corporal",
    "melhora-performance",
  ]),
  nivel: z.enum(["iniciante", "intermediario", "avancado"]),
  nivel_atividade: z.enum([
    "sedentario",
    "levemente-ativo",
    "moderadamente-ativo",
    "ativo",
    "muito-ativo",
  ]),
  lesoes: z.boolean().default(false),
  medicamentos: z.boolean().default(false),
  tem_restricoes_alimentares: z.boolean().default(false),
  restricoes_alimentares: z.string().optional(),
  tem_restricoes_treino: z.boolean().default(false),
  restricoes_treino: z.string().optional(),
  tem_restricoes_hormonais: z.boolean().default(false),
  restricoes_hormonais: z.string().optional(),
})

interface AssessmentFormProps {
  onComplete: (data: z.infer<typeof assessmentSchema>) => void
  initialData?: Partial<z.infer<typeof assessmentSchema>>
}

export default function AssessmentForm({ onComplete, initialData }: AssessmentFormProps) {
  const [hasAlimentaryRestrictions, setHasAlimentaryRestrictions] = useState(
    initialData?.tem_restricoes_alimentares || false
  )
  const [hasTrainingRestrictions, setHasTrainingRestrictions] = useState(
    initialData?.tem_restricoes_treino || false
  )
  const [hasHormonalRestrictions, setHasHormonalRestrictions] = useState(
    initialData?.tem_restricoes_hormonais || false
  )

  const form = useForm<z.infer<typeof assessmentSchema>>({
    resolver: zodResolver(assessmentSchema),
    defaultValues: {
      nome: initialData?.nome || "",
      idade: initialData?.idade || 25,
      genero: initialData?.genero || "masculino",
      peso: initialData?.peso || 70,
      altura: initialData?.altura || 170,
      objetivo: initialData?.objetivo || "perda-peso",
      nivel: initialData?.nivel || "iniciante",
      nivel_atividade: initialData?.nivel_atividade || "moderadamente-ativo",
      lesoes: initialData?.lesoes || false,
      medicamentos: initialData?.medicamentos || false,
      tem_restricoes_alimentares: initialData?.tem_restricoes_alimentares || false,
      restricoes_alimentares: initialData?.restricoes_alimentares || "",
      tem_restricoes_treino: initialData?.tem_restricoes_treino || false,
      restricoes_treino: initialData?.restricoes_treino || "",
      tem_restricoes_hormonais: initialData?.tem_restricoes_hormonais || false,
      restricoes_hormonais: initialData?.restricoes_hormonais || "",
    },
  })

  function onSubmit(values: z.infer<typeof assessmentSchema>) {
    // Limpar campos de detalhes se as restrições não foram selecionadas
    const cleanedValues = {
      ...values,
      restricoes_alimentares: values.tem_restricoes_alimentares ? values.restricoes_alimentares : "",
      restricoes_treino: values.tem_restricoes_treino ? values.restricoes_treino : "",
      restricoes_hormonais: values.tem_restricoes_hormonais ? values.restricoes_hormonais : "",
    }
    onComplete(cleanedValues)
  }

  const objetivoOptions = [
    { value: "perda-peso", label: "Perda de Peso" },
    { value: "ganho-massa", label: "Ganho de Massa Muscular" },
    { value: "melhora-resistencia", label: "Melhora da Resistência" },
    { value: "condicionamento-geral", label: "Condicionamento Físico Geral" },
    { value: "treinamento-forca", label: "Treinamento de Força" },
    { value: "recomposicao-corporal", label: "Recomposição Corporal (Perda de Gordura + Ganho de Músculo)" },
    { value: "melhora-performance", label: "Melhora da Performance" },
  ]

  return (
    <div className="relative">
      {/* Imagem de fundo futurística */}
      <div className="absolute inset-0 rounded-xl overflow-hidden opacity-20">
        <img
          src="/futuristic-assessment.png"
          alt="Futuristic Assessment Interface"
          className="w-full h-full object-cover"
        />
      </div>
      
      <Card className="relative bg-card-futuristic/90 backdrop-blur-sm border-purple-500/30">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="relative">
              <Scan className="w-12 h-12 text-purple-400 animate-pulse-glow" />
              <div className="absolute -top-1 -right-1">
                <Zap className="w-4 h-4 text-cyan-400 animate-bounce" />
              </div>
            </div>
          </div>
          <CardTitle className="text-2xl font-futuristic bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
            Questionário de Avaliação
          </CardTitle>
          <CardDescription className="text-gray-300">
            Preencha o formulário para personalizar seus protocolos com IA
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Informações Pessoais */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-4">
                  <User className="w-5 h-5 text-purple-400" />
                  <h3 className="text-lg font-semibold text-purple-100">Informações Pessoais</h3>
                </div>

                <FormField
                  control={form.control}
                  name="nome"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Nome Completo</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Seu nome completo" 
                          {...field} 
                          className="bg-card-futuristic border-purple-500/30 text-purple-100 placeholder:text-gray-400 focus:border-purple-400 focus:ring-purple-400/20"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="idade"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-300">Idade (anos)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="25" 
                            {...field} 
                            className="bg-card-futuristic border-purple-500/30 text-purple-100 placeholder:text-gray-400 focus:border-purple-400 focus:ring-purple-400/20"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="peso"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-300">Peso (kg)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="70" 
                            {...field} 
                            className="bg-card-futuristic border-cyan-500/30 text-cyan-100 placeholder:text-gray-400 focus:border-cyan-400 focus:ring-cyan-400/20"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="altura"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-300">Altura (cm)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="170" 
                            {...field} 
                            className="bg-card-futuristic border-green-500/30 text-green-100 placeholder:text-gray-400 focus:border-green-400 focus:ring-green-400/20"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="genero"
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormLabel className="text-gray-300">Gênero</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex flex-row space-x-6"
                        >
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="masculino" id="masculino" className="border-purple-500/50 text-purple-400" />
                            </FormControl>
                            <FormLabel htmlFor="masculino" className="text-gray-300">Masculino</FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="feminino" id="feminino" className="border-purple-500/50 text-purple-400" />
                            </FormControl>
                            <FormLabel htmlFor="feminino" className="text-gray-300">Feminino</FormLabel>
                          </FormItem>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Objetivos e Experiência */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-4">
                  <Target className="w-5 h-5 text-cyan-400" />
                  <h3 className="text-lg font-semibold text-cyan-100">Objetivos e Experiência</h3>
                </div>

                <FormField
                  control={form.control}
                  name="objetivo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Objetivo Principal</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-card-futuristic border-cyan-500/30 text-cyan-100 focus:border-cyan-400 focus:ring-cyan-400/20">
                            <SelectValue placeholder="Selecione seu objetivo" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-card-futuristic border-cyan-500/30">
                          {objetivoOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value} className="text-cyan-100 focus:bg-cyan-500/20">
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="nivel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Nível de Treinamento</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-card-futuristic border-cyan-500/30 text-cyan-100 focus:border-cyan-400 focus:ring-cyan-400/20">
                            <SelectValue placeholder="Selecione seu nível" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-card-futuristic border-cyan-500/30">
                          <SelectItem value="iniciante" className="text-cyan-100 focus:bg-cyan-500/20">Iniciante</SelectItem>
                          <SelectItem value="intermediario" className="text-cyan-100 focus:bg-cyan-500/20">Intermediário</SelectItem>
                          <SelectItem value="avancado" className="text-cyan-100 focus:bg-cyan-500/20">Avançado</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="nivel_atividade"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-300">Nível de Atividade Física</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-card-futuristic border-cyan-500/30 text-cyan-100 focus:border-cyan-400 focus:ring-cyan-400/20">
                            <SelectValue placeholder="Selecione seu nível de atividade" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="bg-card-futuristic border-cyan-500/30">
                          <SelectItem value="sedentario" className="text-cyan-100 focus:bg-cyan-500/20">
                            Sedentário (pouco ou nenhum exercício)
                          </SelectItem>
                          <SelectItem value="levemente-ativo" className="text-cyan-100 focus:bg-cyan-500/20">
                            Levemente Ativo (exercício leve 1-3 dias/semana)
                          </SelectItem>
                          <SelectItem value="moderadamente-ativo" className="text-cyan-100 focus:bg-cyan-500/20">
                            Moderadamente Ativo (exercício moderado 3-5 dias/semana)
                          </SelectItem>
                          <SelectItem value="ativo" className="text-cyan-100 focus:bg-cyan-500/20">
                            Ativo (exercício intenso 6-7 dias/semana)
                          </SelectItem>
                          <SelectItem value="muito-ativo" className="text-cyan-100 focus:bg-cyan-500/20">
                            Muito Ativo (exercício muito intenso, trabalho físico)
                          </SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Condições de Saúde */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-4">
                  <Activity className="w-5 h-5 text-green-400" />
                  <h3 className="text-lg font-semibold text-green-100">Condições de Saúde</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="lesoes"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border border-green-500/30 p-4 bg-card-futuristic/50">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            className="border-green-500/50 data-[state=checked]:bg-green-500/20 data-[state=checked]:text-green-400"
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel className="text-green-100">
                            Possui lesões ou limitações físicas
                          </FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="medicamentos"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border border-green-500/30 p-4 bg-card-futuristic/50">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            className="border-green-500/50 data-[state=checked]:bg-green-500/20 data-[state=checked]:text-green-400"
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel className="text-green-100">
                            Faz uso de medicamentos
                          </FormLabel>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              <Button type="submit" className="w-full bg-gradient-to-r from-purple-500 to-cyan-500 hover:from-purple-600 hover:to-cyan-600 text-white font-semibold py-3 rounded-lg glow-purple">
                <Zap className="w-5 h-5 mr-2" />
                Gerar Protocolos Personalizados com IA
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  )
}

