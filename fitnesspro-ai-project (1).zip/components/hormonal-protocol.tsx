"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Activity, Zap, AlertTriangle, Clock, Target, Beaker, Brain, Heart } from "lucide-react"
import { useState } from "react"

interface Supplement {
  name: string
  dosage: string
  timing: string
  purpose: string
  priority: "Alta" | "Média" | "Baixa"
  category: "Hormonal" | "Performance" | "Recuperação" | "Saúde Geral"
  warnings?: string
}

interface HormonalAnalysis {
  hormone: string
  status: "Baixo" | "Normal" | "Alto" | "Atenção"
  recommendation: string
  supplements: string[]
  lifestyle: string[]
}

interface HormonalProtocolProps {
  userProfile: {
    nome: string
    objetivo: string
    nivel: string
    genero: string
    idade: number
    peso: number
    altura: number
    tem_restricoes_hormonais: boolean
    restricoes_hormonais?: string
  }
}

export default function HormonalProtocol({ userProfile }: HormonalProtocolProps) {
  const [activeTab, setActiveTab] = useState("analysis")

  // Gerar análise hormonal baseada no perfil
  const generateHormonalAnalysis = (): HormonalAnalysis[] => {
    const { genero, idade, objetivo } = userProfile
    
    const baseAnalysis: HormonalAnalysis[] = [
      {
        hormone: "Testosterona",
        status: idade > 35 ? "Atenção" : "Normal",
        recommendation: genero === "masculino" 
          ? "Monitorar níveis após os 30 anos. Exercícios de força e sono adequado são essenciais."
          : "Importante para força e composição corporal. Treino de resistência pode ajudar.",
        supplements: ["Vitamina D3", "Zinco", "Magnésio"],
        lifestyle: ["Treino de força", "Sono 7-9h", "Reduzir estresse", "Evitar álcool excessivo"]
      },
      {
        hormone: "Cortisol",
        status: objetivo === "perda-peso" ? "Atenção" : "Normal",
        recommendation: "Hormônio do estresse. Níveis elevados podem dificultar a perda de peso e recuperação.",
        supplements: ["Ashwagandha", "Magnésio", "Ômega-3"],
        lifestyle: ["Meditação", "Sono regular", "Exercício moderado", "Técnicas de relaxamento"]
      },
      {
        hormone: "Hormônio do Crescimento (GH)",
        status: idade > 40 ? "Baixo" : "Normal",
        recommendation: "Essencial para recuperação e composição corporal. Produção diminui com a idade.",
        supplements: ["Arginina", "Ornitina", "GABA"],
        lifestyle: ["Jejum intermitente", "Sono profundo", "Exercício intenso", "Evitar açúcar antes de dormir"]
      },
      {
        hormone: "Insulina",
        status: objetivo === "perda-peso" ? "Atenção" : "Normal",
        recommendation: "Controle da glicemia é crucial para composição corporal e saúde metabólica.",
        supplements: ["Cromo", "Canela", "Berberina"],
        lifestyle: ["Dieta baixa em açúcar", "Exercício pós-refeição", "Jejum intermitente", "Carboidratos complexos"]
      }
    ]

    if (genero === "feminino") {
      baseAnalysis.push({
        hormone: "Estrogênio",
        status: idade > 45 ? "Baixo" : "Normal",
        recommendation: "Importante para saúde óssea, cardiovascular e composição corporal.",
        supplements: ["Isoflavonas", "Vitamina E", "Ômega-3"],
        lifestyle: ["Exercício regular", "Dieta rica em fitoestrógenos", "Controle do peso", "Reduzir xenoestrógenos"]
      })
    }

    return baseAnalysis
  }

  // Gerar protocolo de suplementação
  const generateSupplementProtocol = (): Supplement[] => {
    const { objetivo, genero, idade } = userProfile
    
    const baseSupplements: Supplement[] = [
      {
        name: "Vitamina D3",
        dosage: "2000-4000 UI",
        timing: "Manhã com gordura",
        purpose: "Suporte hormonal, imunidade e saúde óssea",
        priority: "Alta",
        category: "Hormonal"
      },
      {
        name: "Magnésio",
        dosage: "400-600mg",
        timing: "Noite antes de dormir",
        purpose: "Relaxamento, sono e suporte à testosterona",
        priority: "Alta",
        category: "Recuperação"
      },
      {
        name: "Ômega-3 (EPA/DHA)",
        dosage: "2-3g",
        timing: "Com refeições",
        purpose: "Anti-inflamatório, saúde cardiovascular e hormonal",
        priority: "Alta",
        category: "Saúde Geral"
      },
      {
        name: "Zinco",
        dosage: "15-30mg",
        timing: "Estômago vazio ou com proteína",
        purpose: "Suporte à testosterona e recuperação",
        priority: "Média",
        category: "Hormonal",
        warnings: "Não tomar com cálcio ou ferro"
      },
      {
        name: "Ashwagandha",
        dosage: "300-600mg",
        timing: "Manhã ou noite",
        purpose: "Redução do cortisol e adaptógeno",
        priority: "Média",
        category: "Hormonal"
      }
    ]

    if (objetivo === "ganho-massa") {
      baseSupplements.push({
        name: "Creatina",
        dosage: "3-5g",
        timing: "Pós-treino",
        purpose: "Performance e ganho de massa muscular",
        priority: "Alta",
        category: "Performance"
      })
    }

    if (genero === "feminino") {
      baseSupplements.push({
        name: "Ferro",
        dosage: "18-25mg",
        timing: "Estômago vazio com vitamina C",
        purpose: "Prevenção de anemia e energia",
        priority: "Média",
        category: "Saúde Geral",
        warnings: "Apenas se deficiente. Fazer exames regulares"
      })
    }

    return baseSupplements
  }

  const hormonalAnalysis = generateHormonalAnalysis()
  const supplementProtocol = generateSupplementProtocol()

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Baixo": return "bg-red-500/20 text-red-400 border-red-500/30"
      case "Normal": return "bg-green-500/20 text-green-400 border-green-500/30"
      case "Alto": return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
      case "Atenção": return "bg-orange-500/20 text-orange-400 border-orange-500/30"
      default: return "bg-gray-500/20 text-gray-400 border-gray-500/30"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "Alta": return "bg-red-500/20 text-red-400 border-red-500/30"
      case "Média": return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
      case "Baixa": return "bg-green-500/20 text-green-400 border-green-500/30"
      default: return "bg-gray-500/20 text-gray-400 border-gray-500/30"
    }
  }

  return (
    <div className="relative">
      {/* Imagem de fundo futurística */}
      <div className="absolute inset-0 rounded-xl overflow-hidden opacity-15">
        <img
          src="/futuristic-hormonal.png"
          alt="Futuristic Hormonal Interface"
          className="w-full h-full object-cover"
        />
      </div>

      <Card className="relative bg-card-futuristic/90 backdrop-blur-sm border-pink-500/30">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="relative">
              <Activity className="w-12 h-12 text-pink-400 animate-pulse-glow" />
              <div className="absolute -top-1 -right-1">
                <Zap className="w-4 h-4 text-cyan-400 animate-bounce" />
              </div>
            </div>
          </div>
          <CardTitle className="text-2xl font-futuristic bg-gradient-to-r from-pink-400 to-cyan-400 bg-clip-text text-transparent">
            Protocolo Hormonal Avançado
          </CardTitle>
          <CardDescription className="text-gray-300">
            Análise e otimização hormonal personalizada para {userProfile.genero} de {userProfile.idade} anos
          </CardDescription>
        </CardHeader>

        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-card-futuristic border border-pink-500/30">
              <TabsTrigger value="analysis" className="flex items-center gap-2 data-[state=active]:bg-pink-500/30 data-[state=active]:text-pink-100">
                <Beaker className="w-4 h-4" />
                Análise
              </TabsTrigger>
              <TabsTrigger value="supplements" className="flex items-center gap-2 data-[state=active]:bg-pink-500/30 data-[state=active]:text-pink-100">
                <Target className="w-4 h-4" />
                Suplementos
              </TabsTrigger>
              <TabsTrigger value="lifestyle" className="flex items-center gap-2 data-[state=active]:bg-pink-500/30 data-[state=active]:text-pink-100">
                <Heart className="w-4 h-4" />
                Estilo de Vida
              </TabsTrigger>
            </TabsList>

            <TabsContent value="analysis" className="space-y-4 mt-6">
              <div className="space-y-4">
                <h3 className="text-xl font-semibold text-pink-100 text-center">
                  Análise Hormonal Personalizada
                </h3>
                
                {hormonalAnalysis.map((analysis, index) => (
                  <Card key={index} className="bg-card-futuristic/50 border-pink-500/20">
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold text-pink-100 flex items-center gap-2">
                            <Brain className="w-5 h-5 text-pink-400" />
                            {analysis.hormone}
                          </h4>
                          <Badge className={getStatusColor(analysis.status)}>
                            {analysis.status}
                          </Badge>
                        </div>

                        <p className="text-sm text-gray-300">
                          {analysis.recommendation}
                        </p>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <h5 className="text-sm font-medium text-pink-300 mb-2">Suplementos Recomendados:</h5>
                            <ul className="text-sm text-gray-400 space-y-1">
                              {analysis.supplements.map((supplement, suppIndex) => (
                                <li key={suppIndex} className="flex items-center gap-2">
                                  <div className="w-1 h-1 bg-pink-400 rounded-full" />
                                  {supplement}
                                </li>
                              ))}
                            </ul>
                          </div>
                          
                          <div>
                            <h5 className="text-sm font-medium text-cyan-300 mb-2">Mudanças no Estilo de Vida:</h5>
                            <ul className="text-sm text-gray-400 space-y-1">
                              {analysis.lifestyle.map((lifestyle, lifeIndex) => (
                                <li key={lifeIndex} className="flex items-center gap-2">
                                  <div className="w-1 h-1 bg-cyan-400 rounded-full" />
                                  {lifestyle}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="supplements" className="space-y-4 mt-6">
              <div className="space-y-4">
                <h3 className="text-xl font-semibold text-pink-100 text-center">
                  Protocolo de Suplementação
                </h3>
                
                {supplementProtocol.map((supplement, index) => (
                  <Card key={index} className="bg-card-futuristic/50 border-pink-500/20">
                    <CardContent className="p-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <h4 className="font-semibold text-pink-100">{supplement.name}</h4>
                          <div className="flex gap-2">
                            <Badge className={getPriorityColor(supplement.priority)}>
                              {supplement.priority}
                            </Badge>
                            <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                              {supplement.category}
                            </Badge>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="text-cyan-400 font-medium">Dosagem:</span>
                            <div className="text-gray-300">{supplement.dosage}</div>
                          </div>
                          <div>
                            <span className="text-green-400 font-medium">Horário:</span>
                            <div className="text-gray-300">{supplement.timing}</div>
                          </div>
                          <div>
                            <span className="text-yellow-400 font-medium">Objetivo:</span>
                            <div className="text-gray-300">{supplement.purpose}</div>
                          </div>
                        </div>

                        {supplement.warnings && (
                          <div className="flex items-start gap-2 p-3 bg-orange-500/10 border border-orange-500/20 rounded-lg">
                            <AlertTriangle className="w-4 h-4 text-orange-400 mt-0.5 flex-shrink-0" />
                            <p className="text-sm text-orange-300">{supplement.warnings}</p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="lifestyle" className="space-y-4 mt-6">
              <div className="space-y-6">
                <h3 className="text-xl font-semibold text-pink-100 text-center">
                  Otimização do Estilo de Vida
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/30">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Clock className="w-5 h-5 text-blue-400" />
                        <h4 className="font-semibold text-blue-100">Sono e Recuperação</h4>
                      </div>
                      <ul className="text-sm text-gray-300 space-y-2">
                        <li>• Dormir 7-9 horas por noite</li>
                        <li>• Manter horários regulares</li>
                        <li>• Quarto escuro e fresco (18-20°C)</li>
                        <li>• Evitar telas 1h antes de dormir</li>
                        <li>• Suplementar magnésio se necessário</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="bg-gradient-to-br from-green-500/10 to-green-600/10 border-green-500/30">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Heart className="w-5 h-5 text-green-400" />
                        <h4 className="font-semibold text-green-100">Gestão do Estresse</h4>
                      </div>
                      <ul className="text-sm text-gray-300 space-y-2">
                        <li>• Praticar meditação diária</li>
                        <li>• Exercícios de respiração</li>
                        <li>• Atividades relaxantes</li>
                        <li>• Limitar cafeína após 14h</li>
                        <li>• Considerar adaptógenos</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/30">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Target className="w-5 h-5 text-purple-400" />
                        <h4 className="font-semibold text-purple-100">Exercício Otimizado</h4>
                      </div>
                      <ul className="text-sm text-gray-300 space-y-2">
                        <li>• Treino de força 3-4x/semana</li>
                        <li>• HIIT 2-3x/semana</li>
                        <li>• Evitar overtraining</li>
                        <li>• Variar intensidade</li>
                        <li>• Incluir dias de descanso</li>
                      </ul>
                    </CardContent>
                  </Card>

                  <Card className="bg-gradient-to-br from-orange-500/10 to-orange-600/10 border-orange-500/30">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-3">
                        <Beaker className="w-5 h-5 text-orange-400" />
                        <h4 className="font-semibold text-orange-100">Nutrição Hormonal</h4>
                      </div>
                      <ul className="text-sm text-gray-300 space-y-2">
                        <li>• Gorduras saudáveis (20-30%)</li>
                        <li>• Proteína adequada (1.6-2.2g/kg)</li>
                        <li>• Evitar açúcares refinados</li>
                        <li>• Incluir vegetais crucíferos</li>
                        <li>• Considerar jejum intermitente</li>
                      </ul>
                    </CardContent>
                  </Card>
                </div>

                {/* Aviso importante */}
                <Card className="bg-gradient-to-r from-red-500/10 to-orange-500/10 border-red-500/20">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="w-6 h-6 text-red-400 mt-1 flex-shrink-0" />
                      <div>
                        <h4 className="font-semibold text-red-100 mb-2">Aviso Importante</h4>
                        <p className="text-sm text-gray-300">
                          Este protocolo é baseado em informações gerais e não substitui consulta médica. 
                          Recomenda-se realizar exames hormonais antes de iniciar qualquer suplementação. 
                          Consulte sempre um profissional de saúde qualificado.
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}

