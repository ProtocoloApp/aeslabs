"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { AlertCircle, Edit, RefreshCw } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

interface ProtocolAdaptationProps {
  clientData: any
  protocolType: "training" | "diet" | "hormonal"
  onAdapt: (type: string, observations: string) => void
}

export default function ProtocolAdaptation({ clientData, protocolType, onAdapt }: ProtocolAdaptationProps) {
  const [observations, setObservations] = useState("")
  const [adaptationReason, setAdaptationReason] = useState("")
  const [showDialog, setShowDialog] = useState(false)

  // Gerar perguntas específicas baseadas no tipo de protocolo e perfil do cliente
  const generateQuestions = () => {
    const { objetivo, genero, nivel } = clientData
    const questions = []

    // Perguntas gerais por tipo de protocolo
    if (protocolType === "training") {
      questions.push("Está sentindo dificuldade em algum exercício específico?")
      questions.push("Sente que o volume de treino está adequado?")
      questions.push("Está conseguindo recuperar bem entre os treinos?")

      if (objetivo === "perda-peso") {
        questions.push("Gostaria de aumentar o cardio?")
      } else if (objetivo === "ganho-massa") {
        questions.push("Gostaria de aumentar a carga em algum exercício específico?")
      }

      if (nivel === "iniciante") {
        questions.push("Está conseguindo executar os movimentos corretamente?")
      } else if (nivel === "avancado") {
        questions.push("Gostaria de incluir técnicas avançadas como drop-sets ou bi-sets?")
      }
    } else if (protocolType === "diet") {
      questions.push("Está sentindo muita fome entre as refeições?")
      questions.push("Está conseguindo preparar todas as refeições recomendadas?")
      questions.push("Tem alguma restrição alimentar não informada anteriormente?")

      if (objetivo === "perda-peso") {
        questions.push("Está sentindo fraqueza ou tontura durante o dia?")
      } else if (objetivo === "ganho-massa") {
        questions.push("Está conseguindo consumir todo o volume de alimentos recomendado?")
      }
    } else if (protocolType === "hormonal") {
      questions.push("Está sentindo algum efeito colateral com o protocolo atual?")
      questions.push("Realizou os exames de acompanhamento recomendados?")

      if (genero === "masculino") {
        questions.push("Notou alterações na libido ou disposição?")
      } else {
        questions.push("Notou alterações no ciclo menstrual?")
      }

      if (objetivo === "ganho-massa") {
        questions.push("Está notando os resultados esperados em termos de ganho muscular?")
      }
    }

    return questions
  }

  const questions = generateQuestions()

  // Gerar opções de adaptação baseadas no tipo de protocolo
  const generateAdaptationOptions = () => {
    if (protocolType === "training") {
      return [
        { value: "increase-intensity", label: "Aumentar intensidade" },
        { value: "decrease-intensity", label: "Diminuir intensidade" },
        { value: "change-exercises", label: "Mudar exercícios" },
        { value: "adjust-frequency", label: "Ajustar frequência" },
        { value: "focus-specific-area", label: "Focar em área específica" },
      ]
    } else if (protocolType === "diet") {
      return [
        { value: "adjust-calories", label: "Ajustar calorias" },
        { value: "change-macros", label: "Mudar distribuição de macros" },
        { value: "meal-timing", label: "Ajustar horários das refeições" },
        { value: "food-substitution", label: "Substituir alimentos" },
        { value: "add-supplements", label: "Adicionar suplementos" },
      ]
    } else if (protocolType === "hormonal") {
      return [
        { value: "adjust-dosage", label: "Ajustar dosagem" },
        { value: "change-compounds", label: "Mudar compostos" },
        { value: "cycle-length", label: "Ajustar duração do ciclo" },
        { value: "add-support", label: "Adicionar suporte" },
        { value: "post-cycle", label: "Ajustar TPC" },
      ]
    }
    return []
  }

  const adaptationOptions = generateAdaptationOptions()

  const handleAdapt = () => {
    const fullObservations = `Motivo: ${adaptationReason}\n\nObservações: ${observations}`
    onAdapt(protocolType, fullObservations)
    setShowDialog(false)
  }

  const getProtocolTitle = () => {
    switch (protocolType) {
      case "training":
        return "Treino"
      case "diet":
        return "Dieta"
      case "hormonal":
        return "Protocolo Hormonal"
      default:
        return "Protocolo"
    }
  }

  return (
    <Dialog open={showDialog} onOpenChange={setShowDialog}>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full justify-start bg-transparent">
          <Edit className="h-4 w-4 mr-2" />
          Adaptar {getProtocolTitle()}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Adaptar {getProtocolTitle()}</DialogTitle>
          <DialogDescription>
            Informe o que precisa ser adaptado no seu {getProtocolTitle().toLowerCase()} atual para melhorar seus
            resultados.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Adaptações frequentes podem afetar seus resultados. Recomendamos seguir cada protocolo por pelo menos 4-6
              semanas.
            </AlertDescription>
          </Alert>

          <div className="space-y-2">
            <h4 className="font-medium">O que você gostaria de adaptar?</h4>
            <RadioGroup onValueChange={setAdaptationReason} className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {adaptationOptions.map((option) => (
                <div key={option.value} className="flex items-center space-x-2 rounded-md border p-3">
                  <RadioGroupItem value={option.value} id={option.value} />
                  <Label htmlFor={option.value} className="flex-1">
                    {option.label}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          <Separator />

          <div className="space-y-2">
            <h4 className="font-medium">Observações</h4>
            <p className="text-sm text-muted-foreground">
              Responda às perguntas abaixo ou adicione suas próprias observações:
            </p>
            <div className="space-y-2 max-h-40 overflow-y-auto p-2 bg-muted rounded-md">
              {questions.map((question, index) => (
                <div key={index} className="flex items-start gap-2 text-sm">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-auto py-1 px-2 text-xs"
                    onClick={() => setObservations(observations + "\n" + question + " Sim.")}
                  >
                    Sim
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-auto py-1 px-2 text-xs"
                    onClick={() => setObservations(observations + "\n" + question + " Não.")}
                  >
                    Não
                  </Button>
                  <span>{question}</span>
                </div>
              ))}
            </div>
            <Textarea
              placeholder="Adicione suas observações aqui..."
              value={observations}
              onChange={(e) => setObservations(e.target.value)}
              className="min-h-[100px]"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setShowDialog(false)}>
            Cancelar
          </Button>
          <Button onClick={handleAdapt} disabled={!adaptationReason}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Adaptar {getProtocolTitle()}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
