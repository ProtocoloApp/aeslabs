"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Play, Edit, Save, X, Clock } from "lucide-react"

interface Meal {
  name: string
  time: string
  foods: string[]
  calories: number
  macros: {
    protein: number
    carbs: number
    fats: number
  }
  recipeVideo?: string
  preparation?: string
}

interface DietPlanProps {
  clientData: any
}

export default function DietPlan({ clientData }: DietPlanProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [editableNotes, setEditableNotes] = useState("")

  const generateDietPlan = (): Meal[] => {
    const { objetivo, peso, altura, idade, genero, nivel_atividade } = clientData

    // Calcular TMB (Taxa Metabólica Basal)
    let tmb = 0
    if (genero === "masculino") {
      tmb = 88.362 + 13.397 * peso + 4.799 * altura - 5.677 * idade
    } else {
      tmb = 447.593 + 9.247 * peso + 3.098 * altura - 4.33 * idade
    }

    // Ajustar por nível de atividade
    const activityMultiplier = {
      sedentario: 1.2,
      leve: 1.375,
      moderado: 1.55,
      intenso: 1.725,
      "muito-intenso": 1.9,
    }

    const tdee = tmb * (activityMultiplier[nivel_atividade] || 1.55)

    // Ajustar calorias por objetivo
    let targetCalories = tdee
    if (objetivo === "perda-peso") {
      targetCalories = tdee - 500 // Déficit de 500 calorias
    } else if (objetivo === "ganho-massa") {
      targetCalories = tdee + 300 // Superávit de 300 calorias
    }

    if (objetivo === "perda-peso") {
      return [
        {
          name: "Café da Manhã",
          time: "07:00",
          foods: ["2 ovos mexidos", "1 fatia de pão integral", "1/2 abacate", "1 xícara de café sem açúcar"],
          calories: 350,
          macros: { protein: 18, carbs: 25, fats: 22 },
          recipeVideo: "https://www.youtube.com/embed/PUP7U5vTMM0",
          preparation: "Bata os ovos e cozinhe em fogo baixo. Torre o pão e amasse o abacate com uma pitada de sal.",
        },
        {
          name: "Lanche da Manhã",
          time: "10:00",
          foods: ["1 iogurte grego natural", "1 colher de sopa de granola", "Frutas vermelhas (100g)"],
          calories: 180,
          macros: { protein: 15, carbs: 20, fats: 5 },
          recipeVideo: "https://www.youtube.com/embed/dQw4w9WgXcQ",
        },
        {
          name: "Almoço",
          time: "12:30",
          foods: [
            "150g de frango grelhado",
            "1 xícara de arroz integral",
            "Salada verde com azeite",
            "1 porção de legumes refogados",
          ],
          calories: 450,
          macros: { protein: 35, carbs: 40, fats: 12 },
          recipeVideo: "https://www.youtube.com/embed/Ks-_Mh1QhMc",
          preparation: "Tempere o frango com ervas e grelhe. Refogue os legumes com pouco óleo.",
        },
        {
          name: "Lanche da Tarde",
          time: "15:30",
          foods: ["1 maçã", "1 colher de sopa de pasta de amendoim", "Chá verde"],
          calories: 200,
          macros: { protein: 8, carbs: 25, fats: 8 },
          recipeVideo: "https://www.youtube.com/embed/dQw4w9WgXcQ",
        },
        {
          name: "Jantar",
          time: "19:00",
          foods: ["150g de peixe assado", "Batata doce assada (150g)", "Brócolis no vapor", "Salada de folhas verdes"],
          calories: 380,
          macros: { protein: 30, carbs: 35, fats: 10 },
          recipeVideo: "https://www.youtube.com/embed/dQw4w9WgXcQ",
          preparation: "Asse o peixe com limão e ervas. Cozinhe a batata doce no forno.",
        },
        {
          name: "Ceia",
          time: "21:30",
          foods: ["1 xícara de chá de camomila", "2 castanhas do Brasil"],
          calories: 80,
          macros: { protein: 2, carbs: 2, fats: 8 },
        },
      ]
    } else if (objetivo === "ganho-massa") {
      return [
        {
          name: "Café da Manhã",
          time: "07:00",
          foods: [
            "3 ovos mexidos",
            "2 fatias de pão integral",
            "1 banana",
            "1 copo de leite integral",
            "1 colher de sopa de mel",
          ],
          calories: 550,
          macros: { protein: 25, carbs: 60, fats: 18 },
          recipeVideo: "https://www.youtube.com/embed/PUP7U5vTMM0",
        },
        {
          name: "Lanche da Manhã",
          time: "10:00",
          foods: ["Vitamina de whey protein", "1 banana", "1 colher de sopa de aveia", "200ml de leite"],
          calories: 320,
          macros: { protein: 30, carbs: 35, fats: 8 },
          recipeVideo: "https://www.youtube.com/embed/dQw4w9WgXcQ",
        },
        {
          name: "Almoço",
          time: "12:30",
          foods: [
            "200g de carne vermelha magra",
            "1,5 xícara de arroz integral",
            "1 xícara de feijão",
            "Salada com azeite",
            "Legumes refogados",
          ],
          calories: 700,
          macros: { protein: 45, carbs: 70, fats: 20 },
          recipeVideo: "https://www.youtube.com/embed/Ks-_Mh1QhMc",
        },
        {
          name: "Lanche Pré-Treino",
          time: "15:00",
          foods: ["1 banana", "2 colheres de sopa de aveia", "1 colher de sopa de mel", "Café"],
          calories: 250,
          macros: { protein: 6, carbs: 50, fats: 3 },
        },
        {
          name: "Lanche Pós-Treino",
          time: "17:30",
          foods: ["Shake de whey protein", "1 banana", "1 colher de sopa de dextrose"],
          calories: 280,
          macros: { protein: 25, carbs: 40, fats: 2 },
          recipeVideo: "https://www.youtube.com/embed/dQw4w9WgXcQ",
        },
        {
          name: "Jantar",
          time: "19:30",
          foods: ["200g de frango grelhado", "Batata doce assada (200g)", "Legumes no vapor", "Salada com azeite"],
          calories: 520,
          macros: { protein: 40, carbs: 50, fats: 15 },
          recipeVideo: "https://www.youtube.com/embed/dQw4w9WgXcQ",
        },
        {
          name: "Ceia",
          time: "22:00",
          foods: ["200g de iogurte grego", "1 colher de sopa de pasta de amendoim", "1 colher de sopa de mel"],
          calories: 300,
          macros: { protein: 20, carbs: 25, fats: 15 },
        },
      ]
    } else {
      // Condicionamento físico
      return [
        {
          name: "Café da Manhã",
          time: "07:00",
          foods: ["2 ovos cozidos", "1 fatia de pão integral", "1 fruta da estação", "1 xícara de chá verde"],
          calories: 300,
          macros: { protein: 16, carbs: 30, fats: 12 },
        },
        {
          name: "Lanche da Manhã",
          time: "10:00",
          foods: ["1 iogurte natural", "1 colher de sopa de granola"],
          calories: 150,
          macros: { protein: 8, carbs: 20, fats: 4 },
        },
        {
          name: "Almoço",
          time: "12:30",
          foods: ["120g de proteína magra", "1 xícara de arroz integral", "Salada variada", "Legumes cozidos"],
          calories: 400,
          macros: { protein: 30, carbs: 45, fats: 10 },
        },
        {
          name: "Lanche da Tarde",
          time: "15:30",
          foods: ["1 fruta", "Punhado de oleaginosas"],
          calories: 180,
          macros: { protein: 5, carbs: 20, fats: 10 },
        },
        {
          name: "Jantar",
          time: "19:00",
          foods: ["120g de peixe", "Legumes assados", "Salada verde"],
          calories: 320,
          macros: { protein: 25, carbs: 25, fats: 12 },
        },
      ]
    }
  }

  const dietPlan = generateDietPlan()
  const totalCalories = dietPlan.reduce((sum, meal) => sum + meal.calories, 0)
  const totalMacros = dietPlan.reduce(
    (totals, meal) => ({
      protein: totals.protein + meal.macros.protein,
      carbs: totals.carbs + meal.macros.carbs,
      fats: totals.fats + meal.macros.fats,
    }),
    { protein: 0, carbs: 0, fats: 0 },
  )

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Plano Alimentar Personalizado</h2>
          <p className="text-muted-foreground">
            Objetivo: {clientData.objetivo?.replace("-", " ")} | Total: {totalCalories} kcal/dia
          </p>
        </div>
        <Button variant={isEditing ? "destructive" : "outline"} onClick={() => setIsEditing(!isEditing)}>
          {isEditing ? <X className="w-4 h-4 mr-2" /> : <Edit className="w-4 h-4 mr-2" />}
          {isEditing ? "Cancelar" : "Editar Dieta"}
        </Button>
      </div>

      {/* Resumo Nutricional */}
      <Card>
        <CardHeader>
          <CardTitle>Resumo Nutricional Diário</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{totalCalories}</div>
              <div className="text-sm text-muted-foreground">Calorias</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{totalMacros.protein}g</div>
              <div className="text-sm text-muted-foreground">Proteínas</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600">{totalMacros.carbs}g</div>
              <div className="text-sm text-muted-foreground">Carboidratos</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{totalMacros.fats}g</div>
              <div className="text-sm text-muted-foreground">Gorduras</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Refeições */}
      <Tabs defaultValue="timeline" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="timeline">Cronograma</TabsTrigger>
          <TabsTrigger value="recipes">Receitas</TabsTrigger>
        </TabsList>

        <TabsContent value="timeline" className="space-y-4">
          {dietPlan.map((meal, index) => (
            <Card key={index}>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5" />
                    {meal.name}
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{meal.time}</Badge>
                    <Badge>{meal.calories} kcal</Badge>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold mb-2">Alimentos:</h4>
                    <ul className="space-y-1">
                      {meal.foods.map((food, foodIndex) => (
                        <li key={foodIndex} className="text-sm">
                          • {food}
                        </li>
                      ))}
                    </ul>

                    <div className="mt-4 grid grid-cols-3 gap-2 text-sm">
                      <div>
                        <span className="font-medium text-green-600">Proteína:</span>
                        <p>{meal.macros.protein}g</p>
                      </div>
                      <div>
                        <span className="font-medium text-orange-600">Carbs:</span>
                        <p>{meal.macros.carbs}g</p>
                      </div>
                      <div>
                        <span className="font-medium text-purple-600">Gordura:</span>
                        <p>{meal.macros.fats}g</p>
                      </div>
                    </div>

                    {meal.preparation && (
                      <div className="mt-3">
                        <span className="font-medium text-sm">Preparo:</span>
                        <p className="text-sm text-muted-foreground">{meal.preparation}</p>
                      </div>
                    )}
                  </div>

                  {meal.recipeVideo && (
                    <div>
                      <div className="aspect-video rounded-lg overflow-hidden bg-muted">
                        <iframe
                          src={meal.recipeVideo}
                          title={`Receita - ${meal.name}`}
                          className="w-full h-full"
                          allowFullScreen
                        />
                      </div>
                      <Button variant="outline" size="sm" className="w-full mt-2 bg-transparent">
                        <Play className="w-4 h-4 mr-2" />
                        Ver Receita Completa
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="recipes" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            {dietPlan
              .filter((meal) => meal.recipeVideo)
              .map((meal, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="text-lg">{meal.name}</CardTitle>
                    <CardDescription>
                      <Badge className="mr-2">{meal.calories} kcal</Badge>
                      <Badge variant="outline">{meal.time}</Badge>
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="aspect-video rounded-lg overflow-hidden bg-muted mb-3">
                      <iframe
                        src={meal.recipeVideo}
                        title={`Receita - ${meal.name}`}
                        className="w-full h-full"
                        allowFullScreen
                      />
                    </div>
                    <div className="space-y-2">
                      <h5 className="font-medium">Ingredientes:</h5>
                      <ul className="text-sm space-y-1">
                        {meal.foods.map((food, foodIndex) => (
                          <li key={foodIndex}>• {food}</li>
                        ))}
                      </ul>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>
      </Tabs>

      {isEditing && (
        <Card>
          <CardHeader>
            <CardTitle>Observações Nutricionais Personalizadas</CardTitle>
            <CardDescription>
              Adicione restrições alimentares, preferências ou ajustes específicos para este cliente
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Ex: Cliente é intolerante à lactose, substituir leite por bebida vegetal. Aumentar fibras devido a problemas digestivos..."
              value={editableNotes}
              onChange={(e) => setEditableNotes(e.target.value)}
              className="min-h-[100px]"
            />
            <Button className="mt-4">
              <Save className="w-4 h-4 mr-2" />
              Salvar Observações
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
