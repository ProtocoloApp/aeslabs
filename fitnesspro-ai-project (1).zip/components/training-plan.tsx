"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Play, Edit, Save, X } from "lucide-react"

interface Exercise {
  name: string
  sets: string
  reps: string
  rest: string
  videoUrl: string
  notes?: string
}

interface TrainingDay {
  day: string
  focus: string
  exercises: Exercise[]
}

interface TrainingPlanProps {
  clientData: any
}

export default function TrainingPlan({ clientData }: TrainingPlanProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [editableNotes, setEditableNotes] = useState("")

  // Gerar plano baseado no perfil do cliente
  const generateTrainingPlan = (): TrainingDay[] => {
    const { objetivo, nivel, genero, idade } = clientData

    if (objetivo === "perda-peso") {
      return [
        {
          day: "Segunda-feira",
          focus: "Treino Full Body + Cardio",
          exercises: [
            {
              name: "Agachamento Livre",
              sets: "3",
              reps: "12-15",
              rest: "60s",
              videoUrl: "https://www.youtube.com/embed/Dy28eq2PjcM",
              notes: "Mantenha o core contraído",
            },
            {
              name: "Flexão de Braço",
              sets: "3",
              reps: "8-12",
              rest: "60s",
              videoUrl: "https://www.youtube.com/embed/IODxDxX7oi4",
            },
            {
              name: "Prancha",
              sets: "3",
              reps: "30-45s",
              rest: "45s",
              videoUrl: "https://www.youtube.com/embed/pSHjTRCQxIw",
            },
            {
              name: "Burpee",
              sets: "3",
              reps: "8-10",
              rest: "90s",
              videoUrl: "https://www.youtube.com/embed/auBLPXO8Fww",
            },
            {
              name: "Esteira - Caminhada Inclinada",
              sets: "1",
              reps: "20 min",
              rest: "-",
              videoUrl: "https://www.youtube.com/embed/kH2-2vhk4dE",
            },
          ],
        },
        {
          day: "Quarta-feira",
          focus: "Treino de Força + HIIT",
          exercises: [
            {
              name: "Levantamento Terra",
              sets: "4",
              reps: "8-10",
              rest: "90s",
              videoUrl: "https://www.youtube.com/embed/ytGaGIn3SjE",
            },
            {
              name: "Remada Curvada",
              sets: "3",
              reps: "10-12",
              rest: "60s",
              videoUrl: "https://www.youtube.com/embed/FWJR5Ve8bnQ",
            },
            {
              name: "Desenvolvimento com Halteres",
              sets: "3",
              reps: "10-12",
              rest: "60s",
              videoUrl: "https://www.youtube.com/embed/qEwKCR5JCog",
            },
            {
              name: "HIIT - Bike",
              sets: "1",
              reps: "15 min",
              rest: "-",
              videoUrl: "https://www.youtube.com/embed/cZnsLVArIt8",
            },
          ],
        },
        {
          day: "Sexta-feira",
          focus: "Circuito Funcional",
          exercises: [
            {
              name: "Kettlebell Swing",
              sets: "4",
              reps: "15",
              rest: "45s",
              videoUrl: "https://www.youtube.com/embed/YSxHifyI6s8",
            },
            {
              name: "Mountain Climber",
              sets: "3",
              reps: "20",
              rest: "30s",
              videoUrl: "https://www.youtube.com/embed/nmwgirgXLYM",
            },
            {
              name: "Jump Squat",
              sets: "3",
              reps: "12",
              rest: "45s",
              videoUrl: "https://www.youtube.com/embed/A2jzBMNrXwQ",
            },
            {
              name: "Cardio Final - Elíptico",
              sets: "1",
              reps: "15 min",
              rest: "-",
              videoUrl: "https://www.youtube.com/embed/TkkHKu6Q5_M",
            },
          ],
        },
      ]
    } else if (objetivo === "ganho-massa") {
      return [
        {
          day: "Segunda-feira",
          focus: "Peito e Tríceps",
          exercises: [
            {
              name: "Supino Reto",
              sets: "4",
              reps: "8-10",
              rest: "90s",
              videoUrl: "https://www.youtube.com/embed/rT7DgCr-3pg",
            },
            {
              name: "Supino Inclinado",
              sets: "3",
              reps: "10-12",
              rest: "75s",
              videoUrl: "https://www.youtube.com/embed/DbFgADa2PL8",
            },
            {
              name: "Crucifixo",
              sets: "3",
              reps: "12-15",
              rest: "60s",
              videoUrl: "https://www.youtube.com/embed/eozdVDA78K0",
            },
            {
              name: "Tríceps Pulley",
              sets: "4",
              reps: "10-12",
              rest: "60s",
              videoUrl: "https://www.youtube.com/embed/2-LAMcpzODU",
            },
            {
              name: "Tríceps Testa",
              sets: "3",
              reps: "12-15",
              rest: "60s",
              videoUrl: "https://www.youtube.com/embed/d_KZxkY_0cM",
            },
          ],
        },
        {
          day: "Terça-feira",
          focus: "Costas e Bíceps",
          exercises: [
            {
              name: "Puxada Frontal",
              sets: "4",
              reps: "8-10",
              rest: "90s",
              videoUrl: "https://www.youtube.com/embed/CAwf7n6Luuc",
            },
            {
              name: "Remada Baixa",
              sets: "4",
              reps: "10-12",
              rest: "75s",
              videoUrl: "https://www.youtube.com/embed/xQNrFHEMhI4",
            },
            {
              name: "Remada Unilateral",
              sets: "3",
              reps: "12 cada",
              rest: "60s",
              videoUrl: "https://www.youtube.com/embed/roCP6wCXPqo",
            },
            {
              name: "Rosca Direta",
              sets: "4",
              reps: "10-12",
              rest: "60s",
              videoUrl: "https://www.youtube.com/embed/ykJmrZ5v0Oo",
            },
            {
              name: "Rosca Martelo",
              sets: "3",
              reps: "12-15",
              rest: "60s",
              videoUrl: "https://www.youtube.com/embed/zC3nLlEvin4",
            },
          ],
        },
        {
          day: "Quinta-feira",
          focus: "Pernas e Glúteos",
          exercises: [
            {
              name: "Agachamento Livre",
              sets: "4",
              reps: "8-10",
              rest: "2 min",
              videoUrl: "https://www.youtube.com/embed/Dy28eq2PjcM",
            },
            {
              name: "Leg Press",
              sets: "4",
              reps: "12-15",
              rest: "90s",
              videoUrl: "https://www.youtube.com/embed/IZxyjW7MPJQ",
            },
            {
              name: "Stiff",
              sets: "3",
              reps: "12-15",
              rest: "75s",
              videoUrl: "https://www.youtube.com/embed/1uDiW5--rAE",
            },
            {
              name: "Cadeira Extensora",
              sets: "3",
              reps: "15-20",
              rest: "60s",
              videoUrl: "https://www.youtube.com/embed/YyvSfVjQeL0",
            },
            {
              name: "Mesa Flexora",
              sets: "3",
              reps: "15-20",
              rest: "60s",
              videoUrl: "https://www.youtube.com/embed/ELOCsoDSmrg",
            },
          ],
        },
      ]
    } else {
      // Condicionamento físico
      return [
        {
          day: "Segunda-feira",
          focus: "Treino Funcional",
          exercises: [
            {
              name: "Agachamento com Peso Corporal",
              sets: "3",
              reps: "15-20",
              rest: "45s",
              videoUrl: "https://www.youtube.com/embed/Dy28eq2PjcM",
            },
            {
              name: "Flexão Modificada",
              sets: "3",
              reps: "10-15",
              rest: "60s",
              videoUrl: "https://www.youtube.com/embed/IODxDxX7oi4",
            },
            {
              name: "Prancha Lateral",
              sets: "2",
              reps: "20s cada lado",
              rest: "45s",
              videoUrl: "https://www.youtube.com/embed/XeN4pEZZJNE",
            },
            {
              name: "Caminhada Rápida",
              sets: "1",
              reps: "25 min",
              rest: "-",
              videoUrl: "https://www.youtube.com/embed/kH2-2vhk4dE",
            },
          ],
        },
      ]
    }
  }

  const trainingPlan = generateTrainingPlan()

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Plano de Treinamento Personalizado</h2>
          <p className="text-muted-foreground">
            Baseado no seu objetivo: {clientData.objetivo?.replace("-", " ")} | Nível: {clientData.nivel}
          </p>
        </div>
        <Button variant={isEditing ? "destructive" : "outline"} onClick={() => setIsEditing(!isEditing)}>
          {isEditing ? <X className="w-4 h-4 mr-2" /> : <Edit className="w-4 h-4 mr-2" />}
          {isEditing ? "Cancelar" : "Editar Plano"}
        </Button>
      </div>

      {trainingPlan.map((day, dayIndex) => (
        <Card key={dayIndex}>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              {day.day}
              <Badge variant="secondary">{day.focus}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {day.exercises.map((exercise, exerciseIndex) => (
                <div key={exerciseIndex} className="border rounded-lg p-4">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-semibold text-lg mb-2">{exercise.name}</h4>
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="font-medium">Séries:</span>
                          <p>{exercise.sets}</p>
                        </div>
                        <div>
                          <span className="font-medium">Repetições:</span>
                          <p>{exercise.reps}</p>
                        </div>
                        <div>
                          <span className="font-medium">Descanso:</span>
                          <p>{exercise.rest}</p>
                        </div>
                      </div>
                      {exercise.notes && (
                        <div className="mt-2">
                          <span className="font-medium text-sm">Observações:</span>
                          <p className="text-sm text-muted-foreground">{exercise.notes}</p>
                        </div>
                      )}
                    </div>
                    <div>
                      <div className="aspect-video rounded-lg overflow-hidden bg-muted">
                        <iframe
                          src={exercise.videoUrl}
                          title={`Vídeo demonstrativo - ${exercise.name}`}
                          className="w-full h-full"
                          allowFullScreen
                        />
                      </div>
                      <Button variant="outline" size="sm" className="w-full mt-2 bg-transparent">
                        <Play className="w-4 h-4 mr-2" />
                        Assistir Demonstração
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      ))}

      {isEditing && (
        <Card>
          <CardHeader>
            <CardTitle>Observações Personalizadas do Treinador</CardTitle>
            <CardDescription>
              Adicione instruções específicas, modificações ou observações importantes para este cliente
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Ex: Cliente tem limitação no joelho direito, evitar agachamentos profundos. Focar em exercícios unilaterais..."
              value={editableNotes}
              onChange={(e) => setEditableNotes(e.target.value)}
              className="min-h-[100px]"
            />
            <Button className="mt-4">
              <Save className="w-4 h-4 mr-2" />
              Salvar Observações
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
