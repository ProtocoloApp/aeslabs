"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Apple, Droplets, Zap, Clock, Target, ChefHat } from "lucide-react"
import { useState } from "react"

interface Meal {
  name: string
  time: string
  calories: number
  protein: number
  carbs: number
  fat: number
  foods: string[]
  preparation: string
}

interface NutritionPlanProps {
  userProfile: {
    nome: string
    objetivo: string
    nivel: string
    genero: string
    idade: number
    peso: number
    altura: number
    nivel_atividade: string
  }
}

export default function NutritionPlan({ userProfile }: NutritionPlanProps) {
  const [selectedDay, setSelectedDay] = useState(0)

  // Calcular necessidades calóricas
  const calculateCalories = () => {
    const { peso, altura, idade, genero, nivel_atividade, objetivo } = userProfile
    
    // Fórmula de Harris-Benedict
    let bmr = genero === "masculino" 
      ? 88.362 + (13.397 * peso) + (4.799 * altura) - (5.677 * idade)
      : 447.593 + (9.247 * peso) + (3.098 * altura) - (4.330 * idade)

    // Fator de atividade
    const activityFactors = {
      "sedentario": 1.2,
      "levemente-ativo": 1.375,
      "moderadamente-ativo": 1.55,
      "ativo": 1.725,
      "muito-ativo": 1.9
    }

    const tdee = bmr * (activityFactors[nivel_atividade as keyof typeof activityFactors] || 1.55)

    // Ajustar para objetivo
    let targetCalories = tdee
    if (objetivo === "perda-peso") {
      targetCalories = tdee * 0.8 // Déficit de 20%
    } else if (objetivo === "ganho-massa") {
      targetCalories = tdee * 1.15 // Superávit de 15%
    }

    return Math.round(targetCalories)
  }

  // Calcular macronutrientes
  const calculateMacros = (calories: number) => {
    const { objetivo } = userProfile
    
    let proteinRatio = 0.25
    let carbRatio = 0.45
    let fatRatio = 0.30

    if (objetivo === "ganho-massa") {
      proteinRatio = 0.30
      carbRatio = 0.45
      fatRatio = 0.25
    } else if (objetivo === "perda-peso") {
      proteinRatio = 0.35
      carbRatio = 0.35
      fatRatio = 0.30
    }

    return {
      protein: Math.round((calories * proteinRatio) / 4), // 4 cal/g
      carbs: Math.round((calories * carbRatio) / 4), // 4 cal/g
      fat: Math.round((calories * fatRatio) / 9) // 9 cal/g
    }
  }

  const dailyCalories = calculateCalories()
  const dailyMacros = calculateMacros(dailyCalories)

  // Gerar plano alimentar
  const generateMealPlan = (): Meal[] => {
    const { objetivo } = userProfile
    
    const baseMeals: Meal[] = [
      {
        name: "Café da Manhã",
        time: "07:00",
        calories: Math.round(dailyCalories * 0.25),
        protein: Math.round(dailyMacros.protein * 0.20),
        carbs: Math.round(dailyMacros.carbs * 0.30),
        fat: Math.round(dailyMacros.fat * 0.25),
        foods: objetivo === "ganho-massa" 
          ? ["2 ovos inteiros + 2 claras", "2 fatias de pão integral", "1 banana", "1 copo de leite", "1 colher de pasta de amendoim"]
          : ["2 ovos mexidos", "1 fatia de pão integral", "1/2 abacate", "1 xícara de café sem açúcar"],
        preparation: "Ovos mexidos com temperos naturais, pão torrado, frutas frescas"
      },
      {
        name: "Lanche da Manhã",
        time: "10:00",
        calories: Math.round(dailyCalories * 0.10),
        protein: Math.round(dailyMacros.protein * 0.15),
        carbs: Math.round(dailyMacros.carbs * 0.15),
        fat: Math.round(dailyMacros.fat * 0.10),
        foods: ["1 iogurte grego", "1 punhado de castanhas", "1 fruta pequena"],
        preparation: "Iogurte natural com castanhas e frutas vermelhas"
      },
      {
        name: "Almoço",
        time: "12:30",
        calories: Math.round(dailyCalories * 0.35),
        protein: Math.round(dailyMacros.protein * 0.35),
        carbs: Math.round(dailyMacros.carbs * 0.35),
        fat: Math.round(dailyMacros.fat * 0.30),
        foods: objetivo === "ganho-massa"
          ? ["150g de frango grelhado", "1 xícara de arroz integral", "1 xícara de feijão", "Salada verde", "1 colher de azeite"]
          : ["120g de peixe grelhado", "1/2 xícara de quinoa", "Vegetais refogados", "Salada mista"],
        preparation: "Proteína grelhada, carboidratos integrais, vegetais variados"
      },
      {
        name: "Lanche da Tarde",
        time: "15:30",
        calories: Math.round(dailyCalories * 0.15),
        protein: Math.round(dailyMacros.protein * 0.20),
        carbs: Math.round(dailyMacros.carbs * 0.15),
        fat: Math.round(dailyMacros.fat * 0.15),
        foods: ["1 shake de whey protein", "1 banana", "1 colher de aveia"],
        preparation: "Shake pós-treino com frutas e aveia"
      },
      {
        name: "Jantar",
        time: "19:00",
        calories: Math.round(dailyCalories * 0.15),
        protein: Math.round(dailyMacros.protein * 0.10),
        carbs: Math.round(dailyMacros.carbs * 0.05),
        fat: Math.round(dailyMacros.fat * 0.20),
        foods: objetivo === "ganho-massa"
          ? ["100g de carne vermelha magra", "Salada grande", "Vegetais cozidos", "1 colher de azeite"]
          : ["100g de frango", "Salada verde", "Vegetais no vapor"],
        preparation: "Refeição leve com foco em proteínas e vegetais"
      }
    ]

    return baseMeals
  }

  const mealPlan = generateMealPlan()
  const days = ["Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado", "Domingo"]

  return (
    <div className="relative">
      {/* Imagem de fundo futurística */}
      <div className="absolute inset-0 rounded-xl overflow-hidden opacity-15">
        <img
          src="/futuristic-nutrition.png"
          alt="Futuristic Nutrition Interface"
          className="w-full h-full object-cover"
        />
      </div>

      <Card className="relative bg-card-futuristic/90 backdrop-blur-sm border-green-500/30">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="relative">
              <Apple className="w-12 h-12 text-green-400 animate-pulse-glow" />
              <div className="absolute -top-1 -right-1">
                <Zap className="w-4 h-4 text-cyan-400 animate-bounce" />
              </div>
            </div>
          </div>
          <CardTitle className="text-2xl font-futuristic bg-gradient-to-r from-green-400 to-cyan-400 bg-clip-text text-transparent">
            Plano Nutricional Personalizado
          </CardTitle>
          <CardDescription className="text-gray-300">
            Dieta otimizada para {userProfile.objetivo.replace("-", " ")} - {dailyCalories} kcal/dia
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Resumo de macronutrientes */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-br from-green-500/10 to-green-600/10 border-green-500/30">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-400">{dailyCalories}</div>
                <div className="text-sm text-gray-300">Calorias</div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border-blue-500/30">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-400">{dailyMacros.protein}g</div>
                <div className="text-sm text-gray-300">Proteínas</div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-yellow-500/10 to-yellow-600/10 border-yellow-500/30">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-yellow-400">{dailyMacros.carbs}g</div>
                <div className="text-sm text-gray-300">Carboidratos</div>
              </CardContent>
            </Card>
            <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border-purple-500/30">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-purple-400">{dailyMacros.fat}g</div>
                <div className="text-sm text-gray-300">Gorduras</div>
              </CardContent>
            </Card>
          </div>

          {/* Seletor de dias */}
          <div className="flex flex-wrap gap-2 justify-center">
            {days.map((day, index) => (
              <Button
                key={index}
                variant={selectedDay === index ? "default" : "outline"}
                onClick={() => setSelectedDay(index)}
                className={`${
                  selectedDay === index
                    ? "bg-gradient-to-r from-green-500 to-cyan-500 text-white"
                    : "border-green-500/30 text-green-100 hover:bg-green-500/20"
                }`}
              >
                {day}
              </Button>
            ))}
          </div>

          {/* Plano de refeições */}
          <div className="space-y-4">
            <h3 className="text-xl font-semibold text-green-100 text-center">
              {days[selectedDay]}-feira - Plano Alimentar
            </h3>

            {mealPlan.map((meal, index) => (
              <Card key={index} className="bg-card-futuristic/50 border-green-500/20">
                <CardContent className="p-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <ChefHat className="w-5 h-5 text-green-400" />
                        <h4 className="font-semibold text-green-100">{meal.name}</h4>
                        <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                          <Clock className="w-3 h-3 mr-1" />
                          {meal.time}
                        </Badge>
                      </div>
                      <div className="text-sm text-gray-300">
                        {meal.calories} kcal
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div className="text-center">
                        <div className="text-blue-400 font-semibold">{meal.protein}g</div>
                        <div className="text-gray-400">Proteína</div>
                      </div>
                      <div className="text-center">
                        <div className="text-yellow-400 font-semibold">{meal.carbs}g</div>
                        <div className="text-gray-400">Carboidratos</div>
                      </div>
                      <div className="text-center">
                        <div className="text-purple-400 font-semibold">{meal.fat}g</div>
                        <div className="text-gray-400">Gorduras</div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div>
                        <h5 className="text-sm font-medium text-gray-300 mb-1">Alimentos:</h5>
                        <ul className="text-sm text-gray-400 space-y-1">
                          {meal.foods.map((food, foodIndex) => (
                            <li key={foodIndex} className="flex items-center gap-2">
                              <div className="w-1 h-1 bg-green-400 rounded-full" />
                              {food}
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div>
                        <h5 className="text-sm font-medium text-gray-300 mb-1">Preparo:</h5>
                        <p className="text-sm text-gray-400">{meal.preparation}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Dicas de hidratação */}
          <Card className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-cyan-500/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Droplets className="w-5 h-5 text-cyan-400" />
                <h4 className="font-semibold text-cyan-100">Hidratação</h4>
              </div>
              <p className="text-sm text-gray-300">
                Beba pelo menos {Math.round(userProfile.peso * 35)}ml de água por dia 
                ({Math.round((userProfile.peso * 35) / 1000 * 10) / 10}L). 
                Aumente a ingestão nos dias de treino.
              </p>
            </CardContent>
          </Card>
        </CardContent>
      </Card>
    </div>
  )
}

