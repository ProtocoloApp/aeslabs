"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Dumbbell, Clock, Target, Zap, Play, CheckCircle } from "lucide-react"
import { useState } from "react"

interface Exercise {
  name: string
  sets: number
  reps: string
  rest: string
  muscle_group: string
  difficulty: "Iniciante" | "Intermediário" | "Avançado"
  instructions: string
}

interface WorkoutDay {
  day: string
  focus: string
  duration: string
  exercises: Exercise[]
}

interface WorkoutPlanProps {
  userProfile: {
    nome: string
    objetivo: string
    nivel: string
    genero: string
    idade: number
    peso: number
    altura: number
  }
}

export default function WorkoutPlan({ userProfile }: WorkoutPlanProps) {
  const [selectedDay, setSelectedDay] = useState(0)
  const [completedExercises, setCompletedExercises] = useState<Set<string>>(new Set())

  // Gerar plano de treino baseado no perfil do usuário
  const generateWorkoutPlan = (): WorkoutDay[] => {
    const { objetivo, nivel, genero } = userProfile

    const baseExercises = {
      "perda-peso": [
        {
          name: "Burpees",
          sets: 3,
          reps: "10-15",
          rest: "45s",
          muscle_group: "Corpo todo",
          difficulty: "Intermediário" as const,
          instructions: "Movimento completo: agachamento, prancha, flexão, salto"
        },
        {
          name: "Mountain Climbers",
          sets: 3,
          reps: "20 cada perna",
          rest: "30s",
          muscle_group: "Core/Cardio",
          difficulty: "Iniciante" as const,
          instructions: "Posição de prancha, alternando joelhos ao peito rapidamente"
        },
        {
          name: "Jump Squats",
          sets: 4,
          reps: "15-20",
          rest: "60s",
          muscle_group: "Pernas",
          difficulty: "Intermediário" as const,
          instructions: "Agachamento explosivo com salto, aterrissagem suave"
        },
        {
          name: "High Knees",
          sets: 3,
          reps: "30s",
          rest: "30s",
          muscle_group: "Cardio",
          difficulty: "Iniciante" as const,
          instructions: "Corrida no lugar elevando joelhos até a altura do quadril"
        }
      ],
      "ganho-massa": [
        {
          name: "Supino Reto",
          sets: 4,
          reps: "8-12",
          rest: "90s",
          muscle_group: "Peito",
          difficulty: "Intermediário" as const,
          instructions: "Movimento controlado, barra tocando o peito, extensão completa"
        },
        {
          name: "Agachamento Livre",
          sets: 4,
          reps: "10-15",
          rest: "2min",
          muscle_group: "Pernas",
          difficulty: "Avançado" as const,
          instructions: "Descida até 90°, manter coluna ereta, força nos calcanhares"
        },
        {
          name: "Remada Curvada",
          sets: 4,
          reps: "8-12",
          rest: "90s",
          muscle_group: "Costas",
          difficulty: "Intermediário" as const,
          instructions: "Tronco inclinado, puxar barra até abdômen, apertar escápulas"
        },
        {
          name: "Desenvolvimento Militar",
          sets: 3,
          reps: "10-12",
          rest: "90s",
          muscle_group: "Ombros",
          difficulty: "Intermediário" as const,
          instructions: "Barra na altura dos ombros, extensão completa acima da cabeça"
        }
      ]
    }

    const exercises = baseExercises[objetivo as keyof typeof baseExercises] || baseExercises["perda-peso"]

    return [
      {
        day: "Segunda-feira",
        focus: objetivo === "perda-peso" ? "HIIT + Cardio" : "Peito + Tríceps",
        duration: "45-60 min",
        exercises: exercises
      },
      {
        day: "Terça-feira",
        focus: objetivo === "perda-peso" ? "Força + Resistência" : "Costas + Bíceps",
        duration: "50-65 min",
        exercises: exercises.map(ex => ({ ...ex, sets: ex.sets + 1 }))
      },
      {
        day: "Quarta-feira",
        focus: "Descanso Ativo",
        duration: "30 min",
        exercises: [
          {
            name: "Caminhada",
            sets: 1,
            reps: "30 min",
            rest: "-",
            muscle_group: "Cardio leve",
            difficulty: "Iniciante" as const,
            instructions: "Caminhada em ritmo moderado, foco na recuperação"
          }
        ]
      },
      {
        day: "Quinta-feira",
        focus: objetivo === "perda-peso" ? "Circuito Funcional" : "Pernas + Glúteos",
        duration: "45-60 min",
        exercises: exercises
      },
      {
        day: "Sexta-feira",
        focus: objetivo === "perda-peso" ? "Cardio + Core" : "Ombros + Abdômen",
        duration: "40-55 min",
        exercises: exercises.slice(0, 3)
      }
    ]
  }

  const workoutPlan = generateWorkoutPlan()

  const toggleExerciseComplete = (exerciseName: string) => {
    const newCompleted = new Set(completedExercises)
    if (newCompleted.has(exerciseName)) {
      newCompleted.delete(exerciseName)
    } else {
      newCompleted.add(exerciseName)
    }
    setCompletedExercises(newCompleted)
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Iniciante": return "bg-green-500/20 text-green-400 border-green-500/30"
      case "Intermediário": return "bg-yellow-500/20 text-yellow-400 border-yellow-500/30"
      case "Avançado": return "bg-red-500/20 text-red-400 border-red-500/30"
      default: return "bg-gray-500/20 text-gray-400 border-gray-500/30"
    }
  }

  return (
    <div className="relative">
      {/* Imagem de fundo futurística */}
      <div className="absolute inset-0 rounded-xl overflow-hidden opacity-15">
        <img
          src="/futuristic-training.png"
          alt="Futuristic Training Interface"
          className="w-full h-full object-cover"
        />
      </div>

      <Card className="relative bg-card-futuristic/90 backdrop-blur-sm border-purple-500/30">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="relative">
              <Dumbbell className="w-12 h-12 text-purple-400 animate-pulse-glow" />
              <div className="absolute -top-1 -right-1">
                <Zap className="w-4 h-4 text-cyan-400 animate-bounce" />
              </div>
            </div>
          </div>
          <CardTitle className="text-2xl font-futuristic bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
            Plano de Treino Personalizado
          </CardTitle>
          <CardDescription className="text-gray-300">
            Treino otimizado para {userProfile.objetivo.replace("-", " ")} - Nível {userProfile.nivel}
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Seletor de dias */}
          <div className="flex flex-wrap gap-2 justify-center">
            {workoutPlan.map((day, index) => (
              <Button
                key={index}
                variant={selectedDay === index ? "default" : "outline"}
                onClick={() => setSelectedDay(index)}
                className={`${
                  selectedDay === index
                    ? "bg-gradient-to-r from-purple-500 to-cyan-500 text-white"
                    : "border-purple-500/30 text-purple-100 hover:bg-purple-500/20"
                }`}
              >
                {day.day.split("-")[0]}
              </Button>
            ))}
          </div>

          {/* Detalhes do dia selecionado */}
          <div className="space-y-4">
            <div className="text-center space-y-2">
              <h3 className="text-xl font-semibold text-purple-100">
                {workoutPlan[selectedDay].day}
              </h3>
              <div className="flex items-center justify-center gap-4 text-sm text-gray-300">
                <div className="flex items-center gap-1">
                  <Target className="w-4 h-4 text-cyan-400" />
                  {workoutPlan[selectedDay].focus}
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4 text-green-400" />
                  {workoutPlan[selectedDay].duration}
                </div>
              </div>
            </div>

            {/* Lista de exercícios */}
            <div className="space-y-3">
              {workoutPlan[selectedDay].exercises.map((exercise, index) => (
                <Card key={index} className="bg-card-futuristic/50 border-purple-500/20">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center gap-2">
                          <h4 className="font-semibold text-purple-100">{exercise.name}</h4>
                          <Badge className={getDifficultyColor(exercise.difficulty)}>
                            {exercise.difficulty}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                          <div className="text-gray-300">
                            <span className="text-cyan-400">Séries:</span> {exercise.sets}
                          </div>
                          <div className="text-gray-300">
                            <span className="text-green-400">Reps:</span> {exercise.reps}
                          </div>
                          <div className="text-gray-300">
                            <span className="text-yellow-400">Descanso:</span> {exercise.rest}
                          </div>
                          <div className="text-gray-300">
                            <span className="text-purple-400">Grupo:</span> {exercise.muscle_group}
                          </div>
                        </div>

                        <p className="text-sm text-gray-400 mt-2">
                          {exercise.instructions}
                        </p>
                      </div>

                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleExerciseComplete(exercise.name)}
                        className={`ml-4 ${
                          completedExercises.has(exercise.name)
                            ? "text-green-400 hover:text-green-300"
                            : "text-gray-400 hover:text-gray-300"
                        }`}
                      >
                        {completedExercises.has(exercise.name) ? (
                          <CheckCircle className="w-5 h-5" />
                        ) : (
                          <Play className="w-5 h-5" />
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Progresso do treino */}
            <div className="mt-6 p-4 bg-gradient-to-r from-purple-500/10 to-cyan-500/10 rounded-lg border border-purple-500/20">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-300">Progresso do Treino:</span>
                <span className="text-purple-100 font-semibold">
                  {completedExercises.size} / {workoutPlan[selectedDay].exercises.length} exercícios
                </span>
              </div>
              <div className="mt-2 w-full bg-gray-700 rounded-full h-2">
                <div
                  className="bg-gradient-to-r from-purple-500 to-cyan-500 h-2 rounded-full transition-all duration-300"
                  style={{
                    width: `${(completedExercises.size / workoutPlan[selectedDay].exercises.length) * 100}%`
                  }}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

