"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { CalendarIcon, CheckCircle2, Clock, Edit, Plus, RefreshCw } from "lucide-react"

interface ProtocolTimelineProps {
  clientData: any
  currentProtocolNumber: number
  protocolHistory: any[]
  onCreateNewProtocol: (type: "full" | "training" | "diet" | "hormonal", observations: string) => void
}

export default function ProtocolTimeline({
  clientData,
  currentProtocolNumber = 1,
  protocolHistory = [],
  onCreateNewProtocol,
}: ProtocolTimelineProps) {
  const [selectedProtocolType, setSelectedProtocolType] = useState<"full" | "training" | "diet" | "hormonal">("full")
  const [observations, setObservations] = useState("")
  const [showDialog, setShowDialog] = useState(false)

  // Calcular datas
  const startDate = protocolHistory.length > 0 ? new Date(protocolHistory[0].date) : new Date()
  const currentDate = new Date()
  const daysSinceStart = Math.floor((currentDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))
  const monthsSinceStart = Math.floor(daysSinceStart / 30)
  const yearsSinceStart = Math.floor(monthsSinceStart / 12)
  const remainingMonths = monthsSinceStart % 12

  // Gerar perguntas específicas baseadas no perfil do cliente
  const generateQuestions = () => {
    const { objetivo, genero, nivel } = clientData
    const questions = []

    // Perguntas gerais
    questions.push(
      `Você está seguindo o protocolo corretamente há ${yearsSinceStart > 0 ? `${yearsSinceStart} ano(s), ` : ""}${remainingMonths} mês(es) e ${daysSinceStart % 30} dia(s)?`,
    )

    // Perguntas específicas por objetivo
    if (objetivo === "perda-peso") {
      questions.push("Você está conseguindo manter o déficit calórico recomendado?")
      questions.push("Está realizando os exercícios cardiovasculares conforme orientado?")
      questions.push("Notou redução nas medidas corporais?")
    } else if (objetivo === "ganho-massa") {
      questions.push("Está conseguindo consumir todas as calorias recomendadas?")
      questions.push("Está progredindo nas cargas dos exercícios?")
      questions.push("Notou aumento de volume muscular?")
    } else {
      questions.push("Está sentindo melhora na sua resistência física?")
      questions.push("Está conseguindo manter a frequência de treinos recomendada?")
    }

    // Perguntas específicas por gênero
    if (genero === "feminino") {
      questions.push("Notou alterações no ciclo menstrual?")
    }

    // Perguntas específicas por nível
    if (nivel === "iniciante") {
      questions.push("Está se adaptando bem à rotina de exercícios?")
    } else if (nivel === "intermediario") {
      questions.push("Sente que o treino atual está desafiador o suficiente?")
    } else {
      questions.push("Está conseguindo manter a intensidade necessária nos treinos?")
    }

    return questions
  }

  const questions = generateQuestions()

  const handleCreateNewProtocol = () => {
    onCreateNewProtocol(selectedProtocolType, observations)
    setShowDialog(false)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Linha do Tempo de Protocolos
            </div>
            <Badge variant={currentProtocolNumber >= 5 ? "destructive" : "default"}>
              {currentProtocolNumber}/5 Protocolos
            </Badge>
          </CardTitle>
          <CardDescription>Acompanhe sua evolução e adapte seus protocolos ao longo do tempo</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <div className="absolute left-3 top-0 bottom-0 w-0.5 bg-gray-200"></div>

            <div className="space-y-8">
              {/* Protocolo atual */}
              <div className="relative pl-10">
                <div className="absolute left-0 rounded-full bg-primary p-2 text-white">
                  <CheckCircle2 className="h-4 w-4" />
                </div>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h4 className="font-semibold">Protocolo Geral #{currentProtocolNumber}</h4>
                    <p className="text-sm text-muted-foreground">
                      <CalendarIcon className="inline h-3 w-3 mr-1" />
                      {currentDate.toLocaleDateString()}
                    </p>
                  </div>
                  <Badge className="w-fit">Atual</Badge>
                </div>
                <p className="mt-2 text-sm">Protocolo personalizado baseado na sua avaliação mais recente.</p>
              </div>

              {/* Próximo protocolo */}
              {currentProtocolNumber < 5 && (
                <div className="relative pl-10">
                  <div className="absolute left-0 rounded-full border-2 border-dashed border-gray-300 p-2">
                    <Plus className="h-4 w-4 text-gray-400" />
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <h4 className="font-semibold text-gray-500">Próximo Protocolo #{currentProtocolNumber + 1}</h4>
                      <p className="text-sm text-muted-foreground">Adapte seu protocolo quando necessário</p>
                    </div>
                    <Dialog open={showDialog} onOpenChange={setShowDialog}>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm" className="gap-1 bg-transparent">
                          <RefreshCw className="h-3.5 w-3.5" />
                          Adaptar Protocolo
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="sm:max-w-[500px]">
                        <DialogHeader>
                          <DialogTitle>Adaptar Protocolo</DialogTitle>
                          <DialogDescription>
                            Escolha o que deseja adaptar e adicione suas observações para criar um novo protocolo
                            personalizado.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="space-y-2">
                            <h4 className="font-medium">O que você deseja adaptar?</h4>
                            <RadioGroup
                              defaultValue="full"
                              onValueChange={(value) => setSelectedProtocolType(value as any)}
                              className="grid grid-cols-2 gap-2"
                            >
                              <div className="flex items-center space-x-2 rounded-md border p-3">
                                <RadioGroupItem value="full" id="full" />
                                <Label htmlFor="full" className="flex-1">
                                  Protocolo Completo
                                </Label>
                              </div>
                              <div className="flex items-center space-x-2 rounded-md border p-3">
                                <RadioGroupItem value="training" id="training" />
                                <Label htmlFor="training" className="flex-1">
                                  Apenas Treino
                                </Label>
                              </div>
                              <div className="flex items-center space-x-2 rounded-md border p-3">
                                <RadioGroupItem value="diet" id="diet" />
                                <Label htmlFor="diet" className="flex-1">
                                  Apenas Dieta
                                </Label>
                              </div>
                              <div className="flex items-center space-x-2 rounded-md border p-3">
                                <RadioGroupItem value="hormonal" id="hormonal" />
                                <Label htmlFor="hormonal" className="flex-1">
                                  Apenas Hormonal
                                </Label>
                              </div>
                            </RadioGroup>
                          </div>

                          <div className="space-y-2">
                            <h4 className="font-medium">Observações</h4>
                            <p className="text-sm text-muted-foreground">
                              Responda às perguntas abaixo ou adicione suas próprias observações:
                            </p>
                            <div className="space-y-2 max-h-40 overflow-y-auto p-2 bg-muted rounded-md">
                              {questions.map((question, index) => (
                                <div key={index} className="flex items-start gap-2 text-sm">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-auto py-1 px-2 text-xs"
                                    onClick={() => setObservations(observations + "\n" + question + " Sim.")}
                                  >
                                    Sim
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-auto py-1 px-2 text-xs"
                                    onClick={() => setObservations(observations + "\n" + question + " Não.")}
                                  >
                                    Não
                                  </Button>
                                  <span>{question}</span>
                                </div>
                              ))}
                            </div>
                            <Textarea
                              placeholder="Adicione suas observações aqui..."
                              value={observations}
                              onChange={(e) => setObservations(e.target.value)}
                              className="min-h-[100px]"
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setShowDialog(false)}>
                            Cancelar
                          </Button>
                          <Button onClick={handleCreateNewProtocol}>Criar Novo Protocolo</Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              )}

              {/* Limite de protocolos */}
              {currentProtocolNumber >= 5 && (
                <div className="relative pl-10">
                  <div className="absolute left-0 rounded-full bg-gray-200 p-2">
                    <Clock className="h-4 w-4 text-gray-500" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-500">Limite Anual Atingido</h4>
                    <p className="text-sm text-muted-foreground">
                      Você atingiu o limite de 5 protocolos por ano. Um novo ciclo estará disponível em breve.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>

          <Separator className="my-6" />

          <div className="space-y-4">
            <h4 className="font-semibold">Adaptações Rápidas</h4>
            <p className="text-sm text-muted-foreground">
              Você também pode adaptar componentes específicos do seu protocolo atual:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Button
                variant="outline"
                className="justify-start bg-transparent"
                onClick={() => setSelectedProtocolType("training")}
              >
                <Edit className="h-4 w-4 mr-2" />
                Adaptar Treino
              </Button>
              <Button
                variant="outline"
                className="justify-start bg-transparent"
                onClick={() => setSelectedProtocolType("diet")}
              >
                <Edit className="h-4 w-4 mr-2" />
                Adaptar Dieta
              </Button>
              <Button
                variant="outline"
                className="justify-start bg-transparent"
                onClick={() => setSelectedProtocolType("hormonal")}
              >
                <Edit className="h-4 w-4 mr-2" />
                Adaptar Protocolo Hormonal
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
