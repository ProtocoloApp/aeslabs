import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'FitnessPro AI - Sistema Futurístico de Avaliação',
  description: 'Sistema avançado de avaliação física com IA para treinos, dietas e protocolos hormonais personalizados',
  generator: 'FitnessPro AI',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
