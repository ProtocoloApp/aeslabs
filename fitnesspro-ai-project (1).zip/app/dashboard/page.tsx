"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { User, Dumbbell, Apple, Activity, FileText, Download, Clock, Zap, Brain, Cpu } from "lucide-react"
import AssessmentForm from "@/components/assessment-form"
import WorkoutPlan from "@/components/workout-plan"
import NutritionPlan from "@/components/nutrition-plan"
import HormonalProtocol from "@/components/hormonal-protocol"

export default function Dashboard() {
  const [clientData, setClientData] = useState<any>(null)
  const [activeTab, setActiveTab] = useState("assessment")

  // Dados de teste para demonstração
  const testData = {
    nome: "Maria Silva",
    idade: 28,
    peso: 65,
    altura: 165,
    genero: "feminino",
    objetivo: "perda-peso",
    nivel: "intermediario",
    nivel_atividade: "moderadamente-ativo",
    lesoes: false,
    medicamentos: false,
    tem_restricoes_alimentares: false,
    restricoes_alimentares: "",
    tem_restricoes_treino: false,
    restricoes_treino: "",
    tem_restricoes_hormonais: false,
    restricoes_hormonais: ""
  }

  const handleAssessmentComplete = (data: any) => {
    setClientData(data)
    setActiveTab("overview")
  }

  const loadTestData = () => {
    setClientData(testData)
    setActiveTab("overview")
  }

  const exportToPDF = () => {
    // Implementar exportação para PDF
    alert("Funcionalidade de exportação será implementada em breve!")
  }

  if (!clientData) {
    return (
      <div className="min-h-screen bg-futuristic-gradient grid-pattern">
        <div className="container mx-auto p-6">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <div className="flex justify-center mb-6">
                <div className="relative">
                  <Cpu className="w-16 h-16 text-purple-400 animate-pulse-glow" />
                  <div className="absolute -top-2 -right-2">
                    <Zap className="w-6 h-6 text-cyan-400 animate-bounce" />
                  </div>
                </div>
              </div>
              <h1 className="text-4xl font-futuristic font-bold mb-2 bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
                FitnessPro AI
              </h1>
              <p className="text-lg text-gray-300 mb-2">Sistema Futurístico de Avaliação</p>
              <p className="text-sm text-gray-400">Complete a avaliação para gerar protocolos personalizados com IA</p>
              
              {/* Botão para dados de teste */}
              <div className="mt-4">
                <Button 
                  onClick={loadTestData}
                  variant="outline" 
                  className="bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border-cyan-500/30 hover:from-cyan-500/30 hover:to-purple-500/30 text-cyan-100"
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Carregar Dados de Demonstração
                </Button>
              </div>
            </div>
            <div className="bg-card-futuristic rounded-xl p-6 glow-purple">
              <AssessmentForm onComplete={handleAssessmentComplete} />
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-futuristic-gradient grid-pattern">
      <div className="container mx-auto p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h1 className="text-3xl font-futuristic font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
                Painel do Cliente
              </h1>
              <p className="text-gray-300">Protocolos personalizados para {clientData.nome}</p>
            </div>
            <div className="flex gap-2">
              <Button onClick={exportToPDF} variant="outline" className="bg-card-futuristic border-purple-500/30 hover:bg-purple-500/20 glow-purple">
                <Download className="w-4 h-4 mr-2" />
                Exportar PDF
              </Button>
              <Button onClick={() => setClientData(null)} variant="outline" className="bg-card-futuristic border-cyan-500/30 hover:bg-cyan-500/20 glow-cyan">
                Nova Avaliação
              </Button>
            </div>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-card-futuristic border border-purple-500/30 glow-purple">
              <TabsTrigger value="overview" className="flex items-center gap-2 data-[state=active]:bg-purple-500/30 data-[state=active]:text-purple-100">
                <User className="w-4 h-4" />
                Resumo
              </TabsTrigger>
              <TabsTrigger value="workout" className="flex items-center gap-2 data-[state=active]:bg-purple-500/30 data-[state=active]:text-purple-100">
                <Dumbbell className="w-4 h-4" />
                Treino
              </TabsTrigger>
              <TabsTrigger value="nutrition" className="flex items-center gap-2 data-[state=active]:bg-purple-500/30 data-[state=active]:text-purple-100">
                <Apple className="w-4 h-4" />
                Nutrição
              </TabsTrigger>
              <TabsTrigger value="hormonal" className="flex items-center gap-2 data-[state=active]:bg-purple-500/30 data-[state=active]:text-purple-100">
                <Activity className="w-4 h-4" />
                Hormonal
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6 mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Resumo do Cliente */}
                <Card className="bg-card-futuristic border-purple-500/30 glow-purple">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-purple-100">
                      <User className="w-5 h-5 text-purple-400" />
                      Perfil do Cliente
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Nome:</span>
                      <span className="text-purple-100">{clientData.nome}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Idade:</span>
                      <span className="text-purple-100">{clientData.idade} anos</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Gênero:</span>
                      <span className="text-purple-100">{clientData.genero}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Peso:</span>
                      <span className="text-purple-100">{clientData.peso} kg</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Altura:</span>
                      <span className="text-purple-100">{clientData.altura} cm</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">IMC:</span>
                      <Badge className="bg-purple-500/20 text-purple-400 border-purple-500/30">
                        {((clientData.peso / ((clientData.altura / 100) ** 2))).toFixed(1)}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                {/* Objetivos */}
                <Card className="bg-card-futuristic border-cyan-500/30 glow-cyan">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-cyan-100">
                      <Brain className="w-5 h-5 text-cyan-400" />
                      Objetivos & Metas
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Objetivo:</span>
                      <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30">
                        {clientData.objetivo.replace("-", " ")}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Nível:</span>
                      <span className="text-cyan-100">{clientData.nivel}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Atividade:</span>
                      <span className="text-cyan-100">{clientData.nivel_atividade.replace("-", " ")}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Protocolo Atual:</span>
                      <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                        Ativo
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                {/* Status de Saúde */}
                <Card className="bg-card-futuristic border-green-500/30 glow-green">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2 text-green-100">
                      <Activity className="w-5 h-5 text-green-400" />
                      Status de Saúde
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-300">Lesões:</span>
                      <Badge className={clientData.lesoes ? "bg-red-500/20 text-red-400 border-red-500/30" : "bg-green-500/20 text-green-400 border-green-500/30"}>
                        {clientData.lesoes ? "Sim" : "Não"}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Medicamentos:</span>
                      <Badge className={clientData.medicamentos ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" : "bg-green-500/20 text-green-400 border-green-500/30"}>
                        {clientData.medicamentos ? "Sim" : "Não"}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Restr. Alimentares:</span>
                      <Badge className={clientData.tem_restricoes_alimentares ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" : "bg-green-500/20 text-green-400 border-green-500/30"}>
                        {clientData.tem_restricoes_alimentares ? "Sim" : "Não"}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Restr. Treino:</span>
                      <Badge className={clientData.tem_restricoes_treino ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" : "bg-green-500/20 text-green-400 border-green-500/30"}>
                        {clientData.tem_restricoes_treino ? "Sim" : "Não"}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-300">Restr. Hormonais:</span>
                      <Badge className={clientData.tem_restricoes_hormonais ? "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" : "bg-green-500/20 text-green-400 border-green-500/30"}>
                        {clientData.tem_restricoes_hormonais ? "Sim" : "Não"}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Protocolos Gerados por IA */}
              <Card className="bg-card-futuristic border-purple-500/30 glow-purple">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-purple-100">
                    <Brain className="w-5 h-5 text-purple-400" />
                    Protocolos Gerados por IA
                  </CardTitle>
                  <CardDescription className="text-gray-300">
                    Clique nas abas acima para visualizar cada protocolo detalhado
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Button
                      onClick={() => setActiveTab("workout")}
                      className="h-20 bg-gradient-to-br from-purple-500/20 to-purple-600/20 border border-purple-500/30 hover:from-purple-500/30 hover:to-purple-600/30 glow-purple"
                    >
                      <div className="text-center">
                        <Dumbbell className="w-8 h-8 mx-auto mb-2 text-purple-400" />
                        <div className="text-sm font-medium">Plano de Treino</div>
                      </div>
                    </Button>
                    
                    <Button
                      onClick={() => setActiveTab("nutrition")}
                      className="h-20 bg-gradient-to-br from-green-500/20 to-green-600/20 border border-green-500/30 hover:from-green-500/30 hover:to-green-600/30 glow-green"
                    >
                      <div className="text-center">
                        <Apple className="w-8 h-8 mx-auto mb-2 text-green-400" />
                        <div className="text-sm font-medium">Plano Alimentar</div>
                      </div>
                    </Button>
                    
                    <Button
                      onClick={() => setActiveTab("hormonal")}
                      className="h-20 bg-gradient-to-br from-cyan-500/20 to-cyan-600/20 border border-cyan-500/30 hover:from-cyan-500/30 hover:to-cyan-600/30 glow-cyan"
                    >
                      <div className="text-center">
                        <Activity className="w-8 h-8 mx-auto mb-2 text-cyan-400" />
                        <div className="text-sm font-medium">Protocolo Hormonal</div>
                      </div>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="workout" className="mt-6">
              <WorkoutPlan userProfile={clientData} />
            </TabsContent>

            <TabsContent value="nutrition" className="mt-6">
              <NutritionPlan userProfile={clientData} />
            </TabsContent>

            <TabsContent value="hormonal" className="mt-6">
              <HormonalProtocol userProfile={clientData} />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

